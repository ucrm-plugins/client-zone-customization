<?php
declare(strict_types=1);

// Nothing to do here!